def count_in_list(lst, element):
    """
    Counts how many times 'element' appears in 'lst'.

    Args:
        lst (list): A list of elements.
        element (Any): The element to count.

    Returns:
        int: The number of occurrences of 'element' in 'lst'.
    """
    return lst.count(element)